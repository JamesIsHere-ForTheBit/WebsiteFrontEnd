<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $data = json_decode(file_get_contents('php://input'), true);

    $userId        = isset($data['userId'])       ? (int)$data['userId']         : null;
    $items         = isset($data['items'])         ? $data['items']               : [];
    $services      = isset($data['services'])      ? $data['services']            : [];
    $subtotal      = isset($data['subtotal'])      ? (float)$data['subtotal']     : 0;
    $servicesTotal = isset($data['servicesTotal']) ? (float)$data['servicesTotal']: 0;
    $grandTotal    = isset($data['grandTotal'])    ? (float)$data['grandTotal']   : 0;
    $shipping      = isset($data['shipping'])      ? $data['shipping']            : [];

    if (empty($items)) {
        http_response_code(400);
        echo json_encode(['error' => 'No items in order']);
        exit();
    }

    $orderNumber = 'ORD' . strtoupper(substr(md5(uniqid()), 0, 7));

    $stmt = $conn->prepare(
        'INSERT INTO orders (user_id, order_number, total, services_total) VALUES (?, ?, ?, ?)'
    );
    $stmt->bind_param('isdd', $userId, $orderNumber, $grandTotal, $servicesTotal);

    if (!$stmt->execute()) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save order']);
        $stmt->close();
        exit();
    }

    $orderId = $conn->insert_id;
    $stmt->close();

    $itemStmt = $conn->prepare(
        'INSERT INTO order_times (ORDER_ID, product_id, quantity, price) VALUES (?, ?, ?, ?)'
    );

    foreach ($items as $item) {
        $productId = (int)$item['id'];
        $quantity  = (int)$item['quantity'];
        $price     = (float)$item['price'];
        $itemStmt->bind_param('iiid', $orderId, $productId, $quantity, $price);
        $itemStmt->execute();
    }

    $itemStmt->close();

    echo json_encode([
        'success'     => true,
        'orderId'     => $orderId,
        'orderNumber' => $orderNumber
    ]);

} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $userId = isset($_GET['userId']) ? (int)$_GET['userId'] : null;

    if (!$userId) {
        http_response_code(400);
        echo json_encode(['error' => 'User ID required']);
        exit();
    }

    $stmt = $conn->prepare(
        'SELECT id, order_number, total, services_total, created_at FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 10'
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    $orders = [];
    while ($row = $result->fetch_assoc()) {
        $itemStmt = $conn->prepare(
            'SELECT ot.quantity, ot.price, p.name FROM order_times ot JOIN products p ON ot.product_id = p.id WHERE ot.ORDER_ID = ?'
        );
        $itemStmt->bind_param('i', $row['id']);
        $itemStmt->execute();
        $itemResult = $itemStmt->get_result();
        $itemStmt->close();

        $items = [];
        while ($item = $itemResult->fetch_assoc()) {
            $items[] = $item;
        }

        $orders[] = [
            'id'            => $row['id'],
            'orderNumber'   => $row['order_number'],
            'total'         => (float)$row['total'],
            'servicesTotal' => (float)$row['services_total'],
            'createdAt'     => $row['created_at'],
            'items'         => $items
        ];
    }

    echo json_encode(['success' => true, 'orders' => $orders]);

} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}

$conn->close();
