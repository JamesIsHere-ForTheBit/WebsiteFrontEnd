<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

$category    = isset($_GET['category'])    ? trim($_GET['category'])    : '';
$subcategory = isset($_GET['subcategory']) ? trim($_GET['subcategory']) : '';

if (!empty($category) && $category !== 'all') {
    if (!empty($subcategory) && $subcategory !== 'all') {
        $stmt = $conn->prepare('SELECT * FROM products WHERE category = ? AND subcategory = ?');
        $stmt->bind_param('ss', $category, $subcategory);
    } else {
        $stmt = $conn->prepare('SELECT * FROM products WHERE category = ?');
        $stmt->bind_param('s', $category);
    }
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query('SELECT * FROM products');
}

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = [
        'id'          => (int)$row['id'],
        'name'        => $row['name'],
        'price'       => (float)$row['price'],
        'category'    => $row['category'],
        'subcategory' => $row['subcategory'],
        'image'       => $row['image'],
        'description' => $row['description']
    ];
}

echo json_encode(['success' => true, 'products' => $products]);

$conn->close();
