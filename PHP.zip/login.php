<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

$email    = isset($data['email'])    ? trim($data['email']) : '';
$password = isset($data['password']) ? $data['password']    : '';

if (empty($email) || empty($password)) {
    http_response_code(400);
    echo json_encode(['error' => 'Email and password are required']);
    exit();
}

$stmt = $conn->prepare('SELECT id, name, email, password, is_admin FROM users WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user || !password_verify($password, $user['password'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid email or password']);
    exit();
}

echo json_encode([
    'success' => true,
    'user' => [
        'id'       => $user['id'],
        'name'     => $user['name'],
        'email'    => $user['email'],
        'is_admin' => (bool)$user['is_admin']
    ]
]);

$conn->close();
